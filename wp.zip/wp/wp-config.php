<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'maba1194_wp418' );

/** MySQL database username */
define( 'DB_USER', 'maba1194_wp418' );

/** MySQL database password */
define( 'DB_PASSWORD', 'pS93[oOw0)' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'k4rr1oo08c1ay8ybinwlbthtcez54mtha5digbwitvnx68aru49pzhx7u3gnjlhj' );
define( 'SECURE_AUTH_KEY',  '69hucndwxtunzc6naose0fmgyh68pxdzmva4ggi2nhlt2ctyimwjh05cyqvuf7f9' );
define( 'LOGGED_IN_KEY',    'cb3ccwyccnyxqdag3v2nocoe4d52grt1rr7h72klxkkuj4gsralzukbg0pph31qz' );
define( 'NONCE_KEY',        'zxd5oqp0kfrdycdzp0xi17dgxgjuw1tlmncfq4nsvdlwcnhbim049ozdlokggepc' );
define( 'AUTH_SALT',        'p2rw4wzbs8b0mwschluzqkworaqnpw5csqv7sag0hlcw2r7nsxtluuvmcdhzls8y' );
define( 'SECURE_AUTH_SALT', 'itee2apm4gmzpwc4dyvxnlzckzhem9furinaqmk3eoktz5qqn6lzudfqpgkt2djj' );
define( 'LOGGED_IN_SALT',   '5ulbtvkn7bu4taigqp1ne9q8q6tbum720is4pw4pqug2y1zc6xhagovnfjdddq2h' );
define( 'NONCE_SALT',       'i7quspszlxun4toywaodxslclmuoyvhhvza98acsnfnwkdl33cnktjdn98sxol9j' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpaw_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
